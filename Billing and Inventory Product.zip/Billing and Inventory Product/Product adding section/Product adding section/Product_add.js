document.addEventListener("DOMContentLoaded", () => {
    // Get the form element
    const form = document.querySelector(".product_add_container");

    // Handle form submission
    form.addEventListener("submit", (event) => {
        event.preventDefault(); // Prevent the default form submission

        // Get form values
        const productId = document.getElementById("product-id").value.trim();
        const productName = document.getElementById("product-name").value.trim();
        const category = document.getElementById("category").value;
        const price = document.getElementById("price").value.trim();
        const stocks = document.getElementById("available-stocks").value.trim();

        // Validate Product ID
        if (!productId) {
            alert("Product ID is required.");
            return; // Stop further execution if validation fails
        }

        // Validate Product Name
        if (!productName) {
            alert("Product Name is required.");
            return;
        }

        // Validate Category selection
        if (!category) {
            alert("Please select a category.");
            return;
        }

        // Validate Price (must be a positive number)
        if (!price || isNaN(price) || parseFloat(price) <= 0) {
            alert("Please enter a valid price greater than 0.");
            return;
        }

        // Validate Stock Quantity (must be a non-negative number)
        if (!stocks || isNaN(stocks) || parseInt(stocks, 10) < 0) {
            alert("Please enter a valid stock quantity (0 or more).");
            return;
        }

        // If all validations pass, display success message
        alert("Product saved successfully!");

        // Clear the form after successful submission
        form.reset();
    });

    // Handle reset button click
    const resetButton = document.querySelector(".product_add_btn_reset");
    resetButton.addEventListener("click", () => {
        // Confirm before clearing the form
        if (confirm("Are you sure you want to clear the form?")) {
            form.reset(); // Clear the form fields
        }
    });
});
