
// Validate form on submit
function validateForm() {
    let isValid = true;

    // Name validation: only alphabets and at least 3 characters
    const nameInput = document.getElementById('name');
    const nameError = document.getElementById('nameError');
    const nameRegex = /^[A-Za-z\s]{3,}$/;
    if (!nameRegex.test(nameInput.value)) {
        nameError.textContent = "Please enter a valid name (only letters, min 3 characters).";
        isValid = false;
    } else {
        nameError.textContent = "";
    }

    // Email validation
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(emailInput.value)) {
        emailError.textContent = "Please enter a valid email address.";
        isValid = false;
    } else {
        emailError.textContent = "";
    }

    // Message validation: at least 10 characters
    const messageInput = document.getElementById('message');
    const messageError = document.getElementById('messageError');
    if (messageInput.value.trim().length < 10) {
        messageError.textContent = "Please enter a message (min 10 characters).";
        isValid = false;
    } else {
        messageError.textContent = "";
    }

    // Display confirmation message with animation if the form is valid
    if (isValid) {
        const confirmationMessage = document.getElementById('confirmationMessage');
        confirmationMessage.style.display = 'block';

        // Animate the form sliding up and fading out
        gsap.to(".form-container", {
            y: -50, 
            opacity: 0, 
            duration: 0.5,
            ease: "power2.out",
            onComplete: () => {
                // Fade in the confirmation message
                gsap.fromTo(confirmationMessage, 
                    { opacity: 0, y: -20 }, 
                    { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out' });
            }
        });

        // Reset form after 2 seconds
        setTimeout(() => {
            confirmationMessage.style.display = 'none';
            document.getElementById('contactForm').reset();
            gsap.to(".form-container", { opacity: 1, y: 0, duration: 0 }); // Reset position for next submission
        }, 3000);
    }

    return false; // Prevent form submission for demo purposes
}
