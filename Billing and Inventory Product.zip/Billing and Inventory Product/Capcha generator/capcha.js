//generate captcha
function generateCaptcha() {
    const length = 6;
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
    let captcha = '';
    for (let i = 0; i < length; i++) {
        captcha += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    document.getElementById('captcha').innerText = captcha;

}
//validate captcha
function validateCaptcha() {
    const generatedcaptcha = document.getElementById("captcha").innerText;
    const usercaptcha = document.getElementById("captchaInput").value;
    const result = document.getElementById("result");
    if (generatedcaptcha === usercaptcha) {
        result.style.color = "green";
        result.textContent = "Captcha verified successfully!";

    }
    else {
        result.style.color = "red";
        result.textContent = "Invalid Capcha...!"
    }

}


window.onload = generateCaptcha;