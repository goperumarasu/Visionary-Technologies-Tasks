document
  .getElementById("loginForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    window.location.href = "index.html";
  });
let clickCount = 0;

document
  .querySelector("button[type='submit']")
  .addEventListener("click", function (event) {
    event.preventDefault();
    clickCount++;

    if (clickCount === 5) {
      // Create a modal dynamically
      const modal = document.createElement("div");
      modal.setAttribute("id", "myModal");
      modal.style.position = "fixed";
      modal.style.top = "0";
      modal.style.left = "0";
      modal.style.width = "100%";
      modal.style.height = "100%";
      modal.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
      modal.style.display = "flex";
      modal.style.justifyContent = "center";
      modal.style.alignItems = "center";

      const modalContent = document.createElement("div");
      modalContent.style.backgroundColor = "white";
      modalContent.style.padding = "40px";
      modalContent.style.borderRadius = "10px";
      modalContent.style.width = "60%"; // Adjust width for a bigger box
      modalContent.style.height = "70%"; // Adjust height for a bigger box
      modalContent.style.display = "flex";
      modalContent.style.flexDirection = "column";
      modalContent.style.justifyContent = "center";
      modalContent.style.alignItems = "center";
      modalContent.style.boxSizing = "border-box";

      const cancelButton = document.createElement("button");
      cancelButton.textContent = "Cancel";
      cancelButton.style.marginTop = "20px";
      cancelButton.style.padding = "10px 20px";
      cancelButton.style.backgroundColor = "#90EE90"; // Light green color
      cancelButton.style.border = "none";
      cancelButton.style.borderRadius = "5px";
      cancelButton.style.cursor = "pointer";
      cancelButton.style.transition = "background-color 0.3s ease";

      // Hover effect for Cancel button
      cancelButton.onmouseover = function () {
        cancelButton.style.backgroundColor = "#32CD32"; // Darker green on hover
      };

      cancelButton.onmouseout = function () {
        cancelButton.style.backgroundColor = "#90EE90"; // Revert to light green
      };

      cancelButton.onclick = function () {
        modal.style.display = "none";
      };

      modalContent.appendChild(cancelButton);
      modal.appendChild(modalContent);
      document.body.appendChild(modal);
    }
  });
