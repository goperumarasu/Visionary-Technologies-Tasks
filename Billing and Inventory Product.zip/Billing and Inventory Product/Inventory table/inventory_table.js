const inventory = [
    { id: 1, name: "Product A", category: "Category 1", price: 100, stocks: 10 },
    { id: 2, name: "Product B", category: "Category 2", price: 200, stocks: 15 },
    { id: 3, name: "Product C", category: "Category 1", price: 150, stocks: 5 },
    { id: 4, name: "Product D", category: "Category 3", price: 300, stocks: 8 },
    { id: 5, name: "Product E", category: "Category 2", price: 250, stocks: 20 },
    { id: 6, name: "Product F", category: "Category 1", price: 120, stocks: 12 },
    { id: 7, name: "Product G", category: "Category 3", price: 400, stocks: 4 },
    { id: 8, name: "Product H", category: "Category 2", price: 180, stocks: 9 },
    { id: 9, name: "Product I", category: "Category 1", price: 110, stocks: 11 },
    { id: 10, name: "Product J", category: "Category 3", price: 320, stocks: 3 }
];

let currentPage = 0;
const rowsPerPage = 5;
let editingItem = null;

function loadTable() {
    const table = document.getElementById("inventoryTable");
    table.innerHTML = "";

    const start = currentPage * rowsPerPage;
    const end = start + rowsPerPage;
    const visibleData = inventory.slice(start, end);

    visibleData.forEach(item => {
        const row = `<tr>
    <td>${item.id}</td>
    <td>${item.name}</td>
    <td>${item.category}</td>
    <td>${item.price}</td>
    <td>${item.stocks}</td>
    <td>
        <button class="inventory-items-button1" onclick="editItem(${item.id})">Edit</button>
        <button class="inventory-items-button2" onclick="deleteItem(${item.id})">Delete</button>
    </td>
</tr>`;
        table.innerHTML += row;
    });
}

function showNextItems() {
    if ((currentPage + 1) * rowsPerPage < inventory.length) {
        currentPage++;
    } else {
        currentPage = 0; // Reset to the first page if exceeding total items
    }
    loadTable();
}

function showPreviousItems() {
    if (currentPage > 0) {
        currentPage--;
    } else {
        currentPage = Math.floor(inventory.length / rowsPerPage) - 1; // Go to the last page
    }
    loadTable();
}

function filterTable() {
    const searchInput = document.getElementById("searchInput").value.toLowerCase();
    document.querySelectorAll("tbody tr").forEach(row => {
        const cells = Array.from(row.cells);
        const matches = cells.some(cell => cell.textContent.toLowerCase().includes(searchInput));
        row.style.display = matches ? "" : "none";
    });
}

function sortTable() {
    const sortOption = document.getElementById("sortOptions").value;
    if (sortOption === "highprice") {
        inventory.sort((a, b) => b.price - a.price);
    } else if (sortOption === "lowprice") {
        inventory.sort((a, b) => a.price - b.price);
    }
    else if (sortOption === "highstock") {
        inventory.sort((a, b) => b.stocks - a.stocks);
    } else if (sortOption === "lowstock") {
        inventory.sort((a, b) => a.stocks - b.stocks);
    }
    currentPage = 0; // Reset to the first page after sorting
    loadTable();
}

function populateCategoryOptions() {
    const categorySet = new Set(inventory.map(item => item.category));
    const sortCategoryOptions = document.getElementById("sortCategoryOptions");

    categorySet.forEach(category => {
        const option = document.createElement("option");
        option.value = category;
        option.textContent = category;
        sortCategoryOptions.appendChild(option);
    });
}

function filterByCategory() {
    const selectedCategory = document.getElementById("sortCategoryOptions").value;
    const table = document.getElementById("inventoryTable");

    table.innerHTML = ""; // Clear the table

    const filteredInventory = selectedCategory
        ? inventory.filter(item => item.category === selectedCategory)
        : inventory; // Show all if no category selected

    filteredInventory.slice(currentPage * rowsPerPage, (currentPage + 1) * rowsPerPage).forEach(item => {
        const row = `<tr draggable="true" ondragstart="preventDragLine(event)">
    <td>${item.id}</td>
    <td>${item.name}</td>
    <td>${item.category}</td>
    <td>${item.price}</td>
    <td>${item.stocks}</td>
    <td>
        <button class="inventory-items-button1" onclick="editItem(${item.id})">Edit</button>
        <button class="inventory-items-button2" onclick="deleteItem(${item.id})">Delete</button>
    </td>
</tr>`;
        table.innerHTML += row;
    });
}
function preventDragLine(event) {
    event.preventDefault(); // Prevent the default drag behavior
}


function editItem(id) {
    editingItem = inventory.find(item => item.id === id);
    if (editingItem) {
        document.getElementById("editName").value = editingItem.name;
        document.getElementById("editCategory").value = editingItem.category;
        document.getElementById("editPrice").value = editingItem.price;
        document.getElementById("editStocks").value = editingItem.stocks;
        document.getElementById("editModal").style.display = "flex";
    }
}

function saveEdit() {
    alert("saved the edited item")
}

function closeModal() {
    document.getElementById("editModal").style.display = "none";
}

function deleteItem(id) {
    alert("delete item " + id);
}

// Initial load
loadTable();
populateCategoryOptions();