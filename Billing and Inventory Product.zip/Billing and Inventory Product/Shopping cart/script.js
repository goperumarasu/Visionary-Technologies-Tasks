const cartItemsElement = document.getElementById('cart-items');
  const totalItemsElement = document.getElementById('total-items');
  const totalPriceElement = document.getElementById('total-price');
  const searchInputElement = document.getElementById('search-input');

  
  let products = JSON.parse(localStorage.getItem('cartProducts')) || [
    { id: 1, name: 'Sky-Blue T-shirt', description: '', price: 44.00, quantity: 1, img: 'blue shirt.jpg' },
    { id: 2, name: 'Green T-shirt hello world', description: '', price: 55.00, quantity: 1, img: 'green tshirt.webp' },
    { id: 3, name: 'Green T-shirt', description: '', price: 76.00, quantity: 1, img: 'green tshirt.webp' },
    { id: 4, name: 'Green T-shirt', description: '', price: 44.00, quantity: 1, img: 'green tshirt.webp' },
    { id: 5, name: 'White T-shirt', description: '', price: 44.00, quantity: 1, img: 'white t shirt.webp' },
    { id: 6, name: 'White T-shirt', description: '', price: 44.00, quantity: 1, img: 'white t shirt.webp' },
    { id: 7, name: 'Green T-shirt', description: '', price: 76.00, quantity: 1, img: 'green tshirt.webp' },
    { id: 8, name: 'Green T-shirt', description: '', price: 44.00, quantity: 1, img: 'green tshirt.webp' },
    { id: 9, name: 'White T-shirt', description: '', price: 44.00, quantity: 1, img: 'white t shirt.webp' },
    { id: 10, name: 'White T-shirt', description: '', price: 44.00, quantity: 1, img: 'white t shirt.webp' },
    { id: 11, name: 'White T-shirt', description: '', price: 44.00, quantity: 1, img: 'white t shirt.webp' },
    { id: 12, name: 'White T-shirt', description: '', price: 44.00, quantity: 1, img: 'white t shirt.webp' },
    
  ];

  
  function saveToLocalStorage() {
    localStorage.setItem('cartProducts', JSON.stringify(products));
  }

  function renderCart(filteredProducts) {
    cartItemsElement.innerHTML = '';
    let totalItems = 0;
    let totalPrice = 0;

    filteredProducts.forEach(product => {
      const cartItem = document.createElement('div');
      cartItem.classList.add('cart-item');

      cartItem.innerHTML = `
        <img src="${product.img}" alt="${product.name}">
        <div class="details">
          <p>${product.name}</p>
        </div>
        <div class="quantity-controls">
          <button onclick="updateQuantity(${product.id}, -1)">-</button>
          <input type="text" value="${product.quantity}" readonly>
          <button onclick="updateQuantity(${product.id}, 1)">+</button>
        </div>
        <p>€${(product.price * product.quantity).toFixed(2)}</p>
        <button class="delete-btn" onclick="deleteItem(${product.id})">X</button>
      `;

      cartItemsElement.appendChild(cartItem);
      totalItems += product.quantity;
      totalPrice += product.price * product.quantity;
    });

    totalItemsElement.textContent = totalItems;
    totalPriceElement.textContent = totalPrice.toFixed(2);
  }

  function updateQuantity(productId, change) {
    const product = products.find(p => p.id === productId);
    if (product) {
      product.quantity = Math.max(1, product.quantity + change);
      saveToLocalStorage();
      renderCart(products);
    }
  }

  function deleteItem(productId) {
    const productIndex = products.findIndex(p => p.id === productId);
    if (productIndex > -1) {
      products.splice(productIndex, 1);
      saveToLocalStorage();
      renderCart(products);
    }
  }

  function filterItems() {
    const query = searchInputElement.value.toLowerCase();

    const filteredProducts = products.filter(product => {
      const nameMatch = product.name.toLowerCase().includes(query);
      const priceMatch = product.price.toFixed(2).includes(query);
      return nameMatch || priceMatch;
    });

    renderCart(filteredProducts);
  }

  
  renderCart(products);
