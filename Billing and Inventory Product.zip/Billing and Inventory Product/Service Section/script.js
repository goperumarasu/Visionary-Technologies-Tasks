const services = document.querySelectorAll('.service');
const learnMore = document.querySelector('.learn-more');
const learnMoreTitle = learnMore.querySelector('h1');
const learnMoreDescription = learnMore.querySelector('p');
const learnMoreImage = learnMore.querySelector('img');
const mainservice = document.querySelector('.services')

services.forEach(service => {
    service.addEventListener('click', () => {
        const title = service.getAttribute('data-title');
        const description = service.getAttribute('data-description');
        const image = service.getAttribute('data-image');

        learnMoreTitle.textContent = title;
        learnMoreDescription.textContent = description;
        learnMoreImage.src = image;
        learnMore.style.display = 'block';
    });

    learnMore.addEventListener('mouseleave', () => {
        learnMore.style.display = 'none';
    });
});